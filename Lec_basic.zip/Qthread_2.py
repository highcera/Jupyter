from PyQt5.QtCore import *        # 쓰레드 함수를 불러온다.
from PyQt5.QAxContainer import *  # 키움증권의 클레스를 사용할 수 있게 한다.(QAxWidget)
from kiwoom import Kiwoom          # 로그인을 위한 클래스
from PyQt5.QtWidgets import * #PyQt import



class Thread2(QThread):
    def __init__(self, parent):   # 부모의 윈도우 창을 가져올 수 있다.
        super().__init__(parent)  # 부모의 윈도우 창을 초기화 한다.
        self.parent = parent      # 부모의 윈도우를 사용하기 위한 조건


        ################## 키움서버 함수를 사용하기 위해서 kiwoom의 능력을 상속 받는다.
        self.k = Kiwoom()
        ##################

        ################## 사용되는 변수
        self.Find_up_Screen = "2000"         # 계좌평가잔고내역을 받기위한 스크린
        self.Getanal_code = []               # 텍스트 파일에 저장하기 위한 리스트
        ###### 슬롯

        self.k.kiwoom.OnReceiveTrData.connect(self.trdata_slot)  # 내가 알고 있는 Tr 슬롯에다 특정 값을 던져 준다.

        ###### EventLoop

        self.detail_account_info_event_loop = QEventLoop()  # 계좌 이벤트루프

        ###### 계좌정보 가져오기

        self.check_up_class()


    def check_up_class(self):
        print("등락률 상위종목 가져오기")
        self.k.kiwoom.dynamicCall("SetInputValue(QString, QString)", "시장구분", "000")
        self.k.kiwoom.dynamicCall("SetInputValue(QString, QString)", "상하한구분", "2")      # 2는
        self.k.kiwoom.dynamicCall("SetInputValue(QString, QString)", "정렬구분", "3")
        self.k.kiwoom.dynamicCall("SetInputValue(QString, QString)", "종목조건", "10")       # 전체종목
        self.k.kiwoom.dynamicCall("SetInputValue(QString, QString)", "거래량구분", "00000")  # 전체조회
        self.k.kiwoom.dynamicCall("SetInputValue(QString, QString)", "신용조건", "0")  # 전체종목 구분 : 1은 미체결을 뜻한다.
        self.k.kiwoom.dynamicCall("SetInputValue(QString, QString)", "매매금구분", "0")  # 매매구분(매수/매도) : 0은 모든종목을 뜻한다.
        self.k.kiwoom.dynamicCall("CommRqData(QString, QString, int, QString)", "상하한가요청", "opt10017", "0", self.Find_up_Screen)
        self.detail_account_info_event_loop.exec_()

    def trdata_slot(self, sScrNo, sRQName, sTrCode, sRecordName, sPrevNext):

        if sRQName == "상하한가요청":
            column_head = ["종목코드", "종목명", "현재가", "등락률"]
            colCount = len(column_head)
            rowCount = self.k.kiwoom.dynamicCall("GetRepeatCnt(QString, QString)", sTrCode, sRQName)
            self.parent.upupwid.setColumnCount(colCount)                 # 행 갯수
            self.parent.upupwid.setRowCount(rowCount)                    # 열 갯수 (종목 수)
            self.parent.upupwid.setHorizontalHeaderLabels(column_head)   # 행의 이름 삽입


            for index in range(rowCount):  # 멀티데이터 [0] [1] ... [0] [10]
                code = self.k.kiwoom.dynamicCall("GetCommData(QString, QString, int, QString)", sTrCode, sRQName, index, "종목코드")
                code_nm = self.k.kiwoom.dynamicCall("GetCommData(QString, QString, int, QString)", sTrCode, sRQName, index, "종목명")
                currentPrice = abs(int(self.k.kiwoom.dynamicCall("GetCommData(QString, QString, int, QString)", sTrCode, sRQName, index, "현재가")))
                order_no = self.k.kiwoom.dynamicCall("GetCommData(QString, QString, int, QString)", sTrCode, sRQName, index, "등락률")

                code = code.strip()
                code_nm = code_nm.strip()
                order_no = order_no.strip()

                self.parent.upupwid.setItem(index, 0, QTableWidgetItem(str(code)))
                self.parent.upupwid.setItem(index, 1, QTableWidgetItem(str(code_nm)))
                self.parent.upupwid.setItem(index, 2, QTableWidgetItem(str(currentPrice)))
                self.parent.upupwid.setItem(index, 3, QTableWidgetItem(str(order_no)))

                self.Getanal_code.append([code, code_nm, currentPrice])

            self.Getanal_code = self.Getanal_code[0:100]

            for k in self.Getanal_code:

                f = open("dist/up_stock.txt", "a", encoding="utf8")  # "a" 달아 쓴다. "w" 덮어 쓴다. files라느 파이썬 페키지 볼더를 만든다.

                f.write("%s\t%s\t%s\n" % (k[0], k[1], k[2]))  # t는 tap을 의미한다.

                f.close()

            self.detail_account_info_event_loop.exit()

