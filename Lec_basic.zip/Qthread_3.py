from PyQt5.QtCore import *        # 쓰레드 함수를 불러온다.
from PyQt5.QAxContainer import *  # 키움증권의 클레스를 사용할 수 있게 한다.(QAxWidget)
from kiwoom import Kiwoom          # 로그인을 위한 클래스
from PyQt5.QtWidgets import * #PyQt import
import sys
import os


class Thread3(QThread):
    def __init__(self, parent):   # 부모의 윈도우 창을 가져올 수 있다.
        super().__init__(parent)  # 부모의 윈도우 창을 초기화 한다.
        self.parent = parent      # 부모의 윈도우를 사용하기 위한 조건


        ################## 키움서버 함수를 사용하기 위해서 kiwoom의 능력을 상속 받는다.
        self.k = Kiwoom()
        ##################

        ########## 변수 입력
        self.Getanal_code = []
        ##########



        if os.path.exists("dist/2_filter1_Kigwan_foreigner.txt"):  # 우리 운영체재에 이 종목이 존재하냐?

            f = open("dist/2_filter1_Kigwan_foreigner.txt", "r", encoding="utf8")

            lines = f.readlines()  # 여러 종목이 저장되어 있다면 모든 항목을 가져온다.

            for line in lines:
                if line != "":                     # 만약에 line이 비어 있지 않다면
                    ls = line.split("\t")          # \t(tap)로 구분을 지어 놓는다.
                    t_code = ls[0]
                    t_name = ls[1]
                    curren_price = int(ls[2].split("\n")[0])
                    self.Getanal_code.append([t_code, t_name, curren_price])
            f.close()


        if os.path.exists("dist/up_stock.txt"):  # 우리 운영체재에 이 종목이 존재하냐?

            f = open("dist/up_stock.txt", "r", encoding="utf8")

            lines = f.readlines()  # 여러 종목이 저장되어 있다면 모든 항목을 가져온다.

            for line in lines[0:15]:        # 상위 종목 15개만 들고온다.
                if line != "":  # 만약에 line이 비어 있지 않다면
                    ls = line.split("\t")  # \t(tap)로 구분을 지어 놓는다.
                    t_code = ls[0]
                    t_name = ls[1]
                    curren_price = int(ls[2].split("\n")[0])
                    self.Getanal_code.append([t_code, t_name, curren_price])
            f.close()


        column_head = ["종목코드", "종목명", "현재가"]
        colCount = len(column_head)
        rowCount = len(self.Getanal_code)

        self.parent.buylast.setColumnCount(colCount)  # 행 갯수
        self.parent.buylast.setRowCount(rowCount)  # 열 갯수 (종목 수)
        self.parent.buylast.setHorizontalHeaderLabels(column_head)  # 행의 이름 삽입
        self.parent.buylast.setSelectionMode(QAbstractItemView.SingleSelection)

        for index in range(rowCount):

            self.parent.buylast.setItem(index, 0, QTableWidgetItem(str(self.Getanal_code[index][0])))
            self.parent.buylast.setItem(index, 1, QTableWidgetItem(str(self.Getanal_code[index][1])))
            self.parent.buylast.setItem(index, 2, QTableWidgetItem(str(self.Getanal_code[index][2])))









